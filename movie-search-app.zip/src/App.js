import React, { useState } from "react";
import SearchBar from "./components/SearchBar";
import MovieList from "./components/MovieList";
import Loader from "./components/Loader";
import "./App.css";

const API_KEY = "YOUR_API_KEY";

function App() {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const searchMovies = async (title) => {
    if (!title) {
      setError("Please enter a movie title");
      return;
    }

    try {
      setLoading(true);
      setError("");

      const response = await fetch(
        `https://www.omdbapi.com/?s=${title}&apikey=${API_KEY}`
      );

      const data = await response.json();

      if (data.Response === "True") {
        setMovies(data.Search);
      } else {
        setError("Movie not found");
        setMovies([]);
      }

      setLoading(false);
    } catch (err) {
      setError("Something went wrong!");
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1>🎬 Movie Search App</h1>
      <SearchBar searchMovies={searchMovies} />
      {loading && <Loader />}
      {error && <p className="error">{error}</p>}
      <MovieList movies={movies} />
    </div>
  );
}

export default App;